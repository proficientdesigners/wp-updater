jQuery(function($){
	
	$('body').on('click', '#pd_arios_upload_custom_avatar', function(e){
		e.preventDefault();

		var button = $(this),
		custom_uploader = wp.media({
			title: 'Upload custom avatar',
			library : {
				type : 'image'
			},
			button: {
				text: 'Set Avatar'
			},
			multiple: false
		}).on('select', function() {
		var attachment = custom_uploader.state().get('selection').first().toJSON();
		var html = '<img id="pd_arios_custom_avatar_img" src="' + attachment.url + '" style="max-width:96px;" />';
		html += '<input type="hidden" name="pd_arios_custom_wp_avatar" value="'+attachment.id+'" />';
		$('#custom_avatar_img').html(html);
	})
		.open();
	});

	
	$('body').on('click', '#pd_arios_remove_image_button', function(){
		$(this).hide().prev().val('').prev().addClass('button').html('Upload image');
		return false;
	});

});