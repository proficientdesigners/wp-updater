<?php
/**
 * Plugin Name: pd Gravatat Alt
 * Description: pd Gravatat Alt is a private plugin for Arios
 * Plugin URI: https://proficientdesigners.com/
 * Author: Author
 * Author URI: https://proficientdesigners.com/
 * Version: 1.0
 * License: GPL2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: pd_arios
 * Network: false
 */

defined( 'ABSPATH' ) || exit;

$plugin_version = 1.0;

$git_dir = wp_basename( __FILE__, '.php' );

if ( ! class_exists( 'PD_Arios_Custom_Actions' ) )
{
	class PD_Arios_Custom_Actions
	{
		public function __construct()
		{
			add_action( 'admin_enqueue_scripts', [$this, 'enqueue_scripts'] );

			add_filter( 'show_user_profile', [$this, 'add_custom_avatar'], 10, 1 );
			add_filter( 'edit_user_profile', [$this, 'add_custom_avatar'], 10, 1 );

			add_action( 'personal_options_update', [$this, 'save_custom_avatar'], 10, 1 );
			add_action( 'edit_user_profile_update', [$this, 'save_custom_avatar'], 10, 1 );

			add_action( 'user_new_form', [$this, 'add_custom_avatar'], 10, 1 );
		}

		public function enqueue_scripts()
		{
			wp_enqueue_media();
			wp_enqueue_script('pd_arios_js', plugins_url( 'public/js/media-uploader.js', __FILE__ ), ['jquery'], '1.0.0', true);
		}

		public function add_custom_avatar( $user = null )
		{
			$attachment_id = get_user_meta( $user->ID, 'pd_arios_custom_wp_avatar', true );
			$avatar_url = wp_get_attachment_url( $attachment_id );
			?>
			<h2>Custom Avatar</h2>
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th>Custom Avatar Image</th>
						<td id="custom_avatar_img">
							<img alt="" src="<?php echo $avatar_url ?>" onerror="this.onerror=null;this.src='https://secure.gravatar.com/avatar/39e148be084c4555ecd4c3e66d050271?s=96&d=mm&r=g'" class="avatar avatar-96 photo" height="96" width="96">
						</td>
					</tr>
					<tr>
						<th>Upload a custom avatar image</th>
						<td><button id="pd_arios_upload_custom_avatar" type="button" class="button button-primary">Upload</button></td>
					</tr>
					<tr>
						<th>How to show the custom avatar in front end ?</th>
						<td>
							<p>Below is the code snippet to get the img url by passing the user_id as parameter, use the code inside php tag</p>
							<p><code>echo PD_Arios_Custom_Actions::pd_get_author_details( $user_id );</code></p>
						</td>
					</tr>
				</tbody>
			</table>
			<?php
		}

		public function save_custom_avatar( $user_id = null )
		{
			if ( !current_user_can( 'edit_user', $user_id ) )
				return FALSE;

			if ( ! $_POST['pd_arios_custom_wp_avatar'] )
				return FALSE;

			update_user_meta( $user_id, 'pd_arios_custom_wp_avatar', $_POST['pd_arios_custom_wp_avatar'] );
		}

		public static function pd_get_author_details( $user_id = null )
		{
			$c_avatar_att_id 	= get_user_meta( $user_id, 'pd_arios_custom_wp_avatar', true );
			$c_avatar_url		= wp_get_attachment_image_url( $c_avatar_att_id, 'thumbnail' );
			return $c_avatar_url;
		}

	}
	new PD_Arios_Custom_Actions();
}

require_once( plugin_dir_path( __FILE__ ) . 'updater.php' );

$file = plugin_basename( __FILE__ );

new PD_WP_Plugin_Updater( $file, $plugin_version, $git_dir );