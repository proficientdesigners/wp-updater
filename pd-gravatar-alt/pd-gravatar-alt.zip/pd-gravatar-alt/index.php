<?php

# Silence is gold